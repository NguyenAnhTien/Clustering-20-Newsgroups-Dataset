===============================================================================
Clustering 20 Newsgroups Dataset
===============================================================================

-------------------------------------------------------------------------------
The project done as a part of the EE 219 in Winter 2017. 
The goal of the project is clustering using 20 Newsgroups Dataset. 
For more project details, please read the PDF document (Project 4 Description). 
-------------------------------------------------------------------------------

-------------------------------------------------------------------------------
All the code can run by Python. 
-------------------------------------------------------------------------------

-------------------------------------------------------------------------------
All the code is named, and problemx.py corresponds to the corresponding problem.
Directly run problem1.py which is the code for problem 1.
Directly run problem2.py which is the code for problem 2.
Directly run problem3part1.py and problem3part2.py which is the code for problem 3.
Directly run problem4.py which is the code for problem 4.
Directly run problem5part1.py and problem3part2.py which is the code for problem 5.
Directly run problem6part1.py and problem3part2.py which is the code for problem 6.
-------------------------------------------------------------------------------
